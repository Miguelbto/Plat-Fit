import React from 'react';
import { Clock, Users, Zap } from 'lucide-react';

const Menu = () => {
  const menuItems = [
    {
      id: 1,
      name: "Parmegiana de Berinjela",
      description: "Berinjela grelhada com queijo derretido, acompanha arroz branco e batata doce temperada",
      image: "/src/assets/ChatGPT Image 13 de jun. de 2025, 19_00_31.png",
      category: "Vegetariano",
      calories: "420 kcal",
      protein: "18g",
      type: "cutting"
    },
    {
      id: 2,
      name: "Strogonoff de Frango Fit",
      description: "Frango em cubos com molho cremoso light, acompanha arroz branco e batata doce assada",
      image: "/src/assets/ChatGPT Image 13 de jun. de 2025, 18_55_37.png",
      category: "Proteína",
      calories: "485 kcal",
      protein: "35g",
      type: "maintenance"
    },
    {
      id: 3,
      name: "Frango Grelhado Completo",
      description: "Peito de frango temperado com ervas, arroz branco, feijão carioca e mix de vegetais",
      image: "/src/assets/ChatGPT Image 13 de jun. de 2025, 18_53_19.png",
      category: "Proteína",
      calories: "520 kcal",
      protein: "42g",
      type: "bulking"
    },
    {
      id: 4,
      name: "Salmão com Vegetais",
      description: "Filé de salmão grelhado, arroz branco, feijão carioca, brócolis e cenoura refogados",
      image: "/src/assets/ChatGPT Image 13 de jun. de 2025, 18_53_05.png",
      category: "Peixe",
      calories: "465 kcal",
      protein: "38g",
      type: "maintenance"
    },
    {
      id: 5,
      name: "Carne Magra Premium",
      description: "Carne bovina magra grelhada, arroz branco, feijão carioca, abóbora e mix de legumes",
      image: "/src/assets/ChatGPT Image 13 de jun. de 2025, 18_52_53.png",
      category: "Carne",
      calories: "580 kcal",
      protein: "45g",
      type: "bulking"
    }
  ];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'cutting':
        return 'bg-green-100 text-green-800';
      case 'maintenance':
        return 'bg-blue-100 text-blue-800';
      case 'bulking':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'cutting':
        return 'Cutting';
      case 'maintenance':
        return 'Manutenção';
      case 'bulking':
        return 'Bulking';
      default:
        return '';
    }
  };

  return (
    <section id="menu" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Nosso Cardápio
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Refeições prontas para seu dia render mais. Cada prato é cuidadosamente balanceado 
            para atender seus objetivos fitness.
          </p>
        </div>

        {/* Menu Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {menuItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                />
                <div className="absolute top-4 left-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getTypeColor(item.type)}`}>
                    {getTypeLabel(item.type)}
                  </span>
                </div>
                <div className="absolute top-4 right-4 bg-white bg-opacity-90 px-3 py-1 rounded-full">
                  <span className="text-sm font-medium text-gray-700">{item.category}</span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{item.name}</h3>
                <p className="text-gray-600 mb-4 leading-relaxed">{item.description}</p>

                {/* Nutrition Info */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Zap className="h-4 w-4 text-orange-500" />
                      <span className="text-sm font-medium text-gray-700">{item.calories}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Users className="h-4 w-4 text-orange-500" />
                      <span className="text-sm font-medium text-gray-700">{item.protein}</span>
                    </div>
                  </div>
                </div>

                {/* Order Button */}
                <a
                  href="tel:+5511940619777"
                  className="w-full bg-orange-500 text-white py-3 rounded-xl hover:bg-orange-600 transition-colors font-semibold text-center block"
                >
                  Pedir Agora
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-white rounded-2xl p-8 shadow-lg max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Seu objetivo, nossa missão
            </h3>
            <p className="text-gray-600 mb-6">
              Entre em contato conosco para personalizar suas refeições de acordo com seus objetivos específicos.
            </p>
            <a
              href="tel:+5511940619777"
              className="bg-orange-500 text-white px-8 py-4 rounded-full hover:bg-orange-600 transition-colors font-semibold inline-flex items-center space-x-2"
            >
              <span>Falar com Especialista</span>
              <Clock className="h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Menu;