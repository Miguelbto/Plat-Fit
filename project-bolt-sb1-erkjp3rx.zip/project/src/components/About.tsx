import React from 'react';
import { Heart, Target, Award, Users } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Heart,
      title: "Feitas com carinho",
      description: "Cada refeição é preparada com ingredientes selecionados e muito amor pela alimentação saudável."
    },
    {
      icon: Target,
      title: "Foco no seu objetivo",
      description: "Desenvolvemos pratos específicos para cutting, manutenção e bulking, respeitando suas metas."
    },
    {
      icon: Award,
      title: "Qualidade premium",
      description: "Utilizamos apenas ingredientes frescos e de alta qualidade para garantir o melhor sabor."
    },
    {
      icon: Users,
      title: "Para todos os atletas",
      description: "Atendemos desde atletas profissionais até pessoas que buscam uma vida mais saudável."
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-6">
              <h2 className="text-4xl lg:text-5xl font-bold text-gray-900">
                Sobre a
                <span className="text-orange-500 block">Platô Fit</span>
              </h2>
              <p className="text-xl text-gray-600 leading-relaxed">
                Somos uma empresa brasileira especializada em refeições saudáveis e práticas, 
                com foco em alimentação fitness e equilibrada.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Nossa proposta é proporcionar comida saudável, saborosa e acessível para pessoas 
                que valorizam saúde, bem-estar e performance no dia a dia. Entregamos marmitas 
                balanceadas tanto para quem busca perder gordura, quanto para quem quer manter 
                ou ganhar massa muscular.
              </p>
            </div>

            {/* Quote */}
            <div className="bg-orange-50 p-6 rounded-2xl border-l-4 border-orange-500">
              <p className="text-lg font-medium text-gray-800 italic">
                "Entregues com saúde, preparadas com dedicação"
              </p>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="bg-gradient-to-br from-orange-100 to-orange-200 rounded-3xl p-8">
              <img
                src="https://images.pexels.com/photos/1640772/pexels-photo-1640772.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Cozinha Platô Fit"
                className="w-full h-80 object-cover rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>

        {/* Values Grid */}
        <div className="mt-20">
          <h3 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Nossos Valores
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="text-center space-y-4 p-6 rounded-2xl hover:bg-orange-50 transition-colors duration-300"
              >
                <div className="bg-orange-100 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto">
                  <value.icon className="h-8 w-8 text-orange-500" />
                </div>
                <h4 className="text-xl font-bold text-gray-900">{value.title}</h4>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Mission Statement */}
        <div className="mt-20 bg-gradient-to-r from-orange-500 to-orange-600 rounded-3xl p-12 text-center text-white">
          <h3 className="text-3xl font-bold mb-6">Nossa Missão</h3>
          <p className="text-xl leading-relaxed max-w-4xl mx-auto">
            Transformar a alimentação saudável em algo prático, saboroso e acessível, 
            ajudando nossos clientes a alcançarem seus objetivos fitness com refeições 
            de qualidade premium.
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;