import React from 'react';
import { Heart, Phone, Clock, Instagram, Facebook } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
              <div className="bg-orange-500 p-2 rounded-lg">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold">Platô Fit</span>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Refeições saudáveis e saborosas para seu dia render mais. 
              Sua saúde começa pela sua alimentação.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-gray-800 p-2 rounded-lg hover:bg-orange-500 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="bg-gray-800 p-2 rounded-lg hover:bg-orange-500 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold">Links Rápidos</h3>
            <nav className="space-y-3">
              <a href="#home" className="block text-gray-400 hover:text-orange-500 transition-colors">
                Início
              </a>
              <a href="#menu" className="block text-gray-400 hover:text-orange-500 transition-colors">
                Cardápio
              </a>
              <a href="#about" className="block text-gray-400 hover:text-orange-500 transition-colors">
                Sobre
              </a>
              <a href="#contact" className="block text-gray-400 hover:text-orange-500 transition-colors">
                Contato
              </a>
            </nav>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold">Contato</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-orange-500" />
                <a href="tel:+5511940619777" className="text-gray-400 hover:text-white transition-colors">
                  (11) 94061-9777
                </a>
              </div>
              <div className="flex items-start space-x-3">
                <Clock className="h-5 w-5 text-orange-500 mt-0.5" />
                <div className="text-gray-400">
                  <p>Seg-Sex: 8h às 18h</p>
                  <p>Sáb: 8h às 14h</p>
                </div>
              </div>
            </div>
          </div>

          {/* Phrases */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold">Nossa Filosofia</h3>
            <div className="space-y-3 text-gray-400">
              <p className="italic">"Comida saudável com sabor de verdade"</p>
              <p className="italic">"Seu objetivo, nossa missão"</p>
              <p className="italic">"Feitas com carinho, entregues com saúde"</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2025 Platô Fit. Todos os direitos reservados. Desenvolvido com ❤️ para sua saúde.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;