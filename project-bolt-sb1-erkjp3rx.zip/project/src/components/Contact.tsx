import React from 'react';
import { Phone, Clock, MapPin, MessageCircle } from 'lucide-react';

const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Entre em Contato
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Estamos prontos para atender você e criar o plano alimentar perfeito para seus objetivos.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <div className="space-y-8">
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">
                Fale Conosco
              </h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                Nossa equipe está sempre disponível para esclarecer dúvidas, 
                receber pedidos e ajudar você a escolher as melhores opções para sua dieta.
              </p>
            </div>

            {/* Contact Methods */}
            <div className="space-y-6">
              <div className="flex items-start space-x-4 p-6 bg-white rounded-2xl shadow-lg">
                <div className="bg-orange-100 p-3 rounded-xl">
                  <Phone className="h-6 w-6 text-orange-500" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">Telefone</h4>
                  <a
                    href="tel:+5511940619777"
                    className="text-orange-500 hover:text-orange-600 font-medium text-lg"
                  >
                    (11) 94061-9777
                  </a>
                  <p className="text-gray-600 mt-1">Ligue agora para fazer seu pedido</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-6 bg-white rounded-2xl shadow-lg">
                <div className="bg-orange-100 p-3 rounded-xl">
                  <MessageCircle className="h-6 w-6 text-orange-500" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">WhatsApp</h4>
                  <a
                    href="https://wa.me/5511940619777"
                    className="text-orange-500 hover:text-orange-600 font-medium text-lg"
                  >
                    (11) 94061-9777
                  </a>
                  <p className="text-gray-600 mt-1">Converse conosco pelo WhatsApp</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 p-6 bg-white rounded-2xl shadow-lg">
                <div className="bg-orange-100 p-3 rounded-xl">
                  <Clock className="h-6 w-6 text-orange-500" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">Horário de Atendimento</h4>
                  <p className="text-gray-700 font-medium">Segunda a Sexta: 8h às 18h</p>
                  <p className="text-gray-700 font-medium">Sábado: 8h às 14h</p>
                  <p className="text-gray-600 mt-1">Domingo: Fechado</p>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="space-y-8">
            <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-3xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-6">Pronto para começar?</h3>
              <p className="text-lg mb-8 opacity-90">
                Faça seu primeiro pedido agora e descubra como a alimentação saudável 
                pode ser deliciosa e prática.
              </p>
              
              <div className="space-y-4">
                <a
                  href="tel:+5511940619777"
                  className="w-full bg-white text-orange-500 py-4 rounded-xl hover:bg-gray-50 transition-colors font-semibold text-center block"
                >
                  Ligar Agora
                </a>
                <a
                  href="https://wa.me/5511940619777"
                  className="w-full border-2 border-white text-white py-4 rounded-xl hover:bg-white hover:text-orange-500 transition-colors font-semibold text-center block"
                >
                  WhatsApp
                </a>
              </div>
            </div>

            {/* Testimonial */}
            <div className="bg-white p-8 rounded-2xl shadow-lg">
              <div className="flex items-center space-x-4 mb-4">
                <img
                  src="https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100"
                  alt="Cliente satisfeito"
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">Maria Silva</h4>
                  <p className="text-gray-600 text-sm">Cliente há 6 meses</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                "A Platô Fit mudou completamente minha relação com a alimentação. 
                As refeições são deliciosas e me ajudaram a alcançar meus objetivos fitness!"
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;